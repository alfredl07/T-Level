import random
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'chicken_and_rice'

products = [
    {'id': 1, 'name': 'Chicken', 'price': 2.00},
    {'id': 2, 'name': 'Rice', 'price': 1.50},
    {'id': 3, 'name': 'Mac and gloop', 'price': 2.50}
]

def init_db():
    conn = sqlite3.connect('orders.db')
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_number INTEGER,
            first_name TEXT,
            product_quantities TEXT,
            total_price REAL
        )
    ''')
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    return render_template('index.html', products=products)

@app.route('/add_to_basket/<int:product_id>')
def add_to_basket(product_id):
    product = next((item for item in products if item['id'] == product_id), None)
    if product:
        basket = session.get('basket', [])
        # Check if the product already exists in the basket
        for item in basket:
            if item['id'] == product_id:
                item['quantity'] += 1  # Increment the quantity
                break
        else:
            # If product doesn't exist in the basket, add it with quantity 1
            product['quantity'] = 1
            basket.append(product)
        session['basket'] = basket
    return redirect(url_for('index'))


@app.route('/basket')
def basket():
    basket = session.get('basket', [])
    return render_template('basket.html', basket=basket)

@app.route('/remove_from_basket/<int:product_id>')
def remove_from_basket(product_id):
    basket = session.get('basket', [])
    for item in basket:
        if item['id'] == product_id:
            if item['quantity'] > 1:
                item['quantity'] -= 1  # Decrease the quantity
            else:
                basket.remove(item)  # Remove the item if quantity is 1
            break
    session['basket'] = basket
    return redirect(url_for('basket'))


@app.route('/checkout')
def checkout():
    basket = session.get('basket', [])
    total = sum(item['price'] * item['quantity'] for item in basket)
    return render_template('checkout.html', basket=basket, total=total)


@app.route('/confirm_purchase', methods=['POST'])
def confirm_purchase():

    first_name = request.form.get('first_name')
    card_number = request.form.get('card_number')
    expiration_date = request.form.get('expiration_date')
    cvv = request.form.get('cvv')
    basket = session.get('basket', [])

    # Generate a random order number
    order_number = random.randint(100000, 999999)

    product_quantities = {}
    total_price = 0
    for item in basket:
        if item['name'] in product_quantities:
            product_quantities[item['name']] += 1
        else:
            product_quantities[item['name']] = 1
        total_price += item['price']


    conn = sqlite3.connect('orders.db')
    c = conn.cursor()
    c.execute('''
        INSERT INTO orders (order_number, first_name, product_quantities, total_price)
        VALUES (?, ?, ?, ?)
    ''', (order_number, first_name, str(product_quantities), total_price))
    conn.commit()
    conn.close()

    session.pop('basket', None)

    return render_template('confirmation.html', 
                           order_number=order_number, 
                           first_name=first_name, 
                           product_quantities=product_quantities, 
                           total_price=total_price)
@app.route('/confirmation')
def confirmation():

    return render_template('confirmation.html')

if __name__ == '__main__':
    app.run(debug=True)
